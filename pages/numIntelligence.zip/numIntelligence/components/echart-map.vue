<template>
  <div>
    <div id="map" class="chart" :style="{ width: width, height }"></div>
  </div>
</template>

<script>
// import AMapLoader from "@amap/amap-jsapi-loader";

import geoJson from "../../../assets/json/national.json";
import icon1 from "../../../assets/images/numIntelligence/icon24.png";
import icon2 from "../../../assets/images/numIntelligence/icon22.png";
import icon3 from "../../../assets/images/numIntelligence/icon21.png";
import icon4 from "../../../assets/images/numIntelligence/icon23.png";
export default {
  name: "mapJson",
  data() {
    return {
      isShoW: true,
    };
  },
  props: {
    chartId: {
      type: String,
      required: true,
    },
    chartOption: {
      type: Object,
      required: true,
    },
    width: {
      type: String,
      required: false,
    },
    height: {
      type: String,
      required: false,
    },
    zoom: {
      type: Number,
      required: false,
    },
  },
  watch: {
    chartOption: {
      handler(newVal, oldVal) {
        //监听info对象变化
        this.init();
        //do same things...
      },
      deep: true, //深度监听
      immediate: true,
    },
  },
  mounted() {
    this.init();
  },
  methods: {
    init() {
      AMap.plugin(
        [
          "AMap.Scale",
          "AMap.ToolBar",
          "AMap.ControlBar",
          "AMap.Geocoder",
          "AMap.Marker",
          "AMap.CitySearch",
          "AMap.Geolocation",
          "AMap.AutoComplete",
          "AMap.InfoWindow",
          "AMap.DistrictSearch",
          "AMap.Object3DLayer",
          "AMap.Autocomplete",
          "AMap.PlaceSearch",
          "AMap.OverView",
          "AMap.MapType",
          "AMap.PolyEditor",
          "AMap.CircleEditor",
          ,
          "AMap.HawkEye",
          "AMap.MouseTool",
        ],
        () => {
          this.coverup();
        }
      );
    },
    coverup() {
      var opts = {
        subdistrict: 0,
        extensions: "all",
        level: "city",
      };
      var district = new AMap.DistrictSearch(opts);
      district.search("中国", (status, result) => {
        console.log(111, status, result);
        var bounds = result.districtList[0].boundaries;

        var mask = [];
        for (var i = 0; i < bounds.length; i += 1) {
          mask.push([bounds[i]]);
        }

        //给地图绘制wall
        //  var object3Dlayer = new AMap.Object3DLayer({ zIndex: 100 });
        // map.add(object3Dlayer);
        // var height = -80000;
        // var color = "#051B3D";
        // var wall = new AMap.Object3D.Wall({
        //   path: bounds,
        //   height: height,
        //   color: color,
        // });
        // wall.transparent = true;
        // object3Dlayer.add(wall);

        // var imageLayer = new AMap.ImageLayer({
        //   zooms: [6, 20],
        //   // bounds:new AMap.Bounds(bounds),
        //   url:'',
        //   bounds: new AMap.Bounds(
        //     [71.36618,17.363011],
        //     [
        //       137.108368,54.808156]
        //   ),
        //   visible: true
        // });

        var map = new AMap.Map("map", {
          mask: mask,
          center: [105.166417, 33.798078],
          disableSocket: true,
          viewMode: "2D",
          showLabel: true,
          labelzIndex: 130,
          pitch: 40,
          zoom: this.zoom ? this.zoom : 4,
          zooms: [4, 30],
          mapStyle: "amap://styles/darkblue",
          backgroundColor: "transparent",
          // layers:[AMap.createDefaultLayer(), imageLayer]
          // mapStyle: 'amap://styles/grey',
        });
        //添加描边
        for (var i = 0; i < bounds.length; i += 1) {
          new AMap.Polyline({
            path: bounds[i],
            strokeColor: "#99ffff",
            strokeWeight: 1,
            map: map,
          });
        }

        console.log(this.chartOption.data);
        // if(this.chartOption.data&&this.chartOption.data.length){

        // }
        this.getLoca(map);
      });
    },
    getLoca(map) {
      console.log("渲染点");
      var loca = new Loca.Container({
        map,
      });

      var labelsLayer = (window.labelsLayer = new Loca.LabelsLayer({
        zooms: [4, 30],
      }));
      var geo = new Loca.GeoJSONSource({
        // url: 'https://a.amap.com/Loca/static/loca-v2/demos/mock_data/charging_pile.json',
        data: {
          type: "FeatureCollection",
          features: this.chartOption.data,
        },
      });

      labelsLayer.setSource(geo);

      // labelsLayer.setStyle的配置项即AMap.LabelMarker的配置项
      labelsLayer.setStyle({
        icon: {
          type: "image",
          image: (index, feat) => {
            return feat.properties.type == 0
              ? icon1
              : feat.properties.type == 1
              ? icon2
              : feat.properties.type == 2
              ? icon3
              : icon4;
          },
          size: [15, 15],
          offset: [0, 0],
        },

        extData: (index, feat) => {
          return feat.properties;
        },
      });
      loca.add(labelsLayer);
      labelsLayer.on("complete", () => {
        var normalMarker = new AMap.Marker({
          offset: [0, 0],
        });
        var labelMarkers = labelsLayer.getLabelsLayer().getAllOverlays();
        for (let marker of labelMarkers) {
          marker.on("mouseover", (e) => {
            var position = e.data.data && e.data.data.position;
            if (position) {
              normalMarker.setContent(
                '<div class="amap-info-window" style="display:inline-block;line-height:30px;color:#26FDF0;text-align:center">公司：' +
                  marker.getExtData().name +
                  "</div>"
              );
              normalMarker.setPosition(position);
              map.add(normalMarker);
            }
          });
          // marker.on("mouseout", () => {
          //   map.remove(normalMarker);
          // });
        }
      });
    },
  },
};
</script>

<style>
.amap-info-window {
  display: inline-block;

 min-width: 200px;
  font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
  font-weight: 400;
  font-size: 18px;
  color: #26fdf0;
  line-height: 28px;
  text-align: center;
  position: relative;
}
.amap-info-window::before {
  content: "";
  display: block;
  width: 5px;
  height: 100%;
  background: url(../../../assets/images/numIntelligence/left.png) no-repeat 0 0;
  background-size: 100% 100%;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
.amap-info-window::after {
  content: "";
  display: block;
  width: 5px;
  height: 100%;
  background: url(../../../assets/images/numIntelligence/right.png) no-repeat 0
    0;
  background-size: 100% 100%;
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
<style scoped>
.chart {
  width: 100%;
  height: 100%;
}
.amap-container {
  background-image: none;
  display: inline-block;
}
</style>
